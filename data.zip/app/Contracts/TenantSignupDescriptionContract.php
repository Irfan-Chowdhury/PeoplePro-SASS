<?php

namespace App\Contracts;

interface TenantSignupDescriptionContract extends BaseContract
{
    // Add your signature here
}