<?php

namespace App\Contracts;

interface ModuleDetailContract extends BaseContract
{
    
}
