<?php

namespace App\Contracts;

interface FeatureContract extends BaseContract {

    /**
     * FeatureController.
     */
}
