<?php

namespace App\Contracts;

interface ModuleContract extends BaseContract
{
    
}
