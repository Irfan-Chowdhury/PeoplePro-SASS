<?php

namespace App\Contracts;

interface FaqContract extends BaseContract
{
    // Add your signature here
}