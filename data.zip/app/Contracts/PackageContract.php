<?php

namespace App\Contracts;

interface PackageContract extends BaseContract
{
    // Add your signature here
}