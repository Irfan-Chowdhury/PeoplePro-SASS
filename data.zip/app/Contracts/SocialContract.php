<?php

namespace App\Contracts;

interface SocialContract extends BaseContract {

    /**
     * SocialController.
     */
}
