<?php

namespace App\Contracts;

interface AnalyticSettingContract extends BaseContract
{
    // Add your signature here
}