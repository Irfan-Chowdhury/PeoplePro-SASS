<?php

namespace App\Facades;

use Illuminate\Support\Facades\Facade;

class Utility extends Facade
{
    public static function getFacadeAccessor(){
        return 'utility';
    }
}


