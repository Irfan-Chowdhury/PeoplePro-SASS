<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TravelType extends Model
{
	protected $fillable = [
		'arrangement_type'
	];
}
