<?php


namespace App\Http\traits;

trait TestTrait
{
    public function test()
    {
        return 95;
    }
}
