<?php

namespace App\Contracts;

interface SeoSettingContract extends BaseContract
{
    // Add your signature here
}