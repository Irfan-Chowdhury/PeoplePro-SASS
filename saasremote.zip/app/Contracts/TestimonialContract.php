<?php

namespace App\Contracts;

interface TestimonialContract extends BaseContract
{
    // Add your signature here
}