<?php

namespace App\Contracts;

interface BlogContract extends BaseContract
{
    // Add your signature here
}