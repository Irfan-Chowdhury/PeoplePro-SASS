<?php

namespace App\Contracts;

interface PageContract extends BaseContract
{
    // Add your signature here
}