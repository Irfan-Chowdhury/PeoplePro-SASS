<?php

namespace App\Contracts;

interface GeneralSettingContract extends BaseContract
{
    // Add your service logic here
}
