<?php

namespace App\Contracts;

interface PaymentSettingContract extends BaseContract
{
    // Add your signature here
}