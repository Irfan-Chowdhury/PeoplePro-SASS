<?php

namespace App\Contracts;

interface FaqDetailContract extends BaseContract
{
    // Add your signature here
}