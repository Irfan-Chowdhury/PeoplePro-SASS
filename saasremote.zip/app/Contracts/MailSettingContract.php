<?php

namespace App\Contracts;

interface MailSettingContract extends BaseContract
{
    // Add your signature here
}