
    <link rel="stylesheet" href="<?php echo asset('../../vendor/fullcalendar/packages/core/main.css') ?>"
          type="text/css">
    <link rel="stylesheet" href="<?php echo asset('../../vendor/fullcalendar/packages/daygrid/main.css') ?>"
          type="text/css">
    <link rel="stylesheet" href="<?php echo asset('../../vendor/fullcalendar/packages/timegrid/main.css') ?>"
          type="text/css">
    <link rel="stylesheet" href="<?php echo asset('../../vendor/fullcalendar/packages/list/main.css') ?>"
          type="text/css">
