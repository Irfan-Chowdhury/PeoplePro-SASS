<?php

return array (
  'failed' => 'ব্যর্থ',
);
